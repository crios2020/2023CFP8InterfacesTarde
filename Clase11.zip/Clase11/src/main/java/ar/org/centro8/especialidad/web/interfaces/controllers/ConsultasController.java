package ar.org.centro8.especialidad.web.interfaces.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.especialidad.web.interfaces.entities.Candidato;
import ar.org.centro8.especialidad.web.interfaces.repositories.CandidatoRepository;

@Controller
public class ConsultasController {

    @Autowired
    private CandidatoRepository cr;

    @GetMapping("/consultas")
    public String getConsultas(
            @RequestParam(name="buscar", defaultValue="")String buscar,
            Model model){
        //model.addAttribute("all", cr.findAll());
        System.out.println("********************************************");
        System.out.println(buscar);
        System.out.println("********************************************");
        model.addAttribute("all", 
            ((List<Candidato>)cr.findAll())
                .stream()
                .filter(
                    c->(
                        (c.getEstudios_secundarios_titulo()!=null &&
                            c.getEstudios_secundarios_titulo()
                                .toLowerCase()
                                .contains(buscar.toLowerCase()))
                        ||
                        (c.getEstudios_terciarios_titulo()!=null &&
                            c.getEstudios_terciarios_titulo()
                                .toLowerCase()
                                .contains(buscar.toLowerCase()))
                        ||
                        (c.getEstudios_universitarios_titulo()!=null &&
                            c.getEstudios_universitarios_titulo()
                                .toLowerCase()
                                .contains(buscar.toLowerCase()))            
                        ||
                        (c.getHabilidades()!=null &&
                            c.getHabilidades()
                                .toLowerCase()
                                .contains(buscar.toLowerCase())) 
                    )
                )
                .toList()
            );
        return "consultas";
    }
}
