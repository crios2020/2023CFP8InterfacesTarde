package ar.org.centro8.especialidad.web.interfaces.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.especialidad.web.interfaces.entities.Candidato;
import ar.org.centro8.especialidad.web.interfaces.enums.Respuesta;
import ar.org.centro8.especialidad.web.interfaces.repositories.CandidatoRepository;

@Controller
public class CandidatoController {

    private String mensaje="Ingrese sus datos personales para postularse!";
    private boolean primario=false;
    private boolean secundario=false;
    private boolean terciario=false;
    private boolean universitario=false;

    @Autowired
    private CandidatoRepository cr;

    @GetMapping("/candidato")
    public String getCandidato(Model model){
        Candidato candidato=new Candidato();
        candidato.setEstudios_primarios(Respuesta.n);
        candidato.setEstudios_secundarios(Respuesta.n);
        candidato.setEstudios_terciarios(Respuesta.n);
        candidato.setEstudios_universitarios(Respuesta.n);
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("candidato", candidato);
        model.addAttribute("primario", primario);
        model.addAttribute("secundario", secundario);
        model.addAttribute("terciario", terciario);
        model.addAttribute("universitario", universitario);
        return "candidato";
    }

    @PostMapping("/save")
    public String save( @ModelAttribute Candidato candidato,
                        @RequestParam(name="estudios_pri", defaultValue="false")boolean estudios_pri,
                        @RequestParam(name="estudios_sec", defaultValue="false")boolean estudios_sec,
                        @RequestParam(name="estudios_ter", defaultValue="false")boolean estudios_ter,
                        @RequestParam(name="estudios_uni", defaultValue="false")boolean estudios_uni
                        ){
        candidato.setEstudios_primarios(estudios_pri?Respuesta.s:Respuesta.n);
        candidato.setEstudios_secundarios(estudios_sec?Respuesta.s:Respuesta.n);
        candidato.setEstudios_terciarios(estudios_ter?Respuesta.s:Respuesta.n);
        candidato.setEstudios_universitarios(estudios_uni?Respuesta.s:Respuesta.n);
        //System.out.println("***************************************");
        //System.out.println(candidato);
        //System.out.println(estudios_pri);
        //System.out.println("***************************************");
        cr.save(candidato);
        if(candidato.getId()>=0){
            mensaje="Se guardo el candidato "+candidato.getId();
        }else{
            mensaje="No se pudo guardar el candidator!";
        }
        return "redirect:candidato";
    }

}
