package ar.org.centro8.especialidad.web.interfaces.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.org.centro8.especialidad.web.interfaces.entities.Candidato;
import ar.org.centro8.especialidad.web.interfaces.repositories.CandidatoRepository;

@RestController
@RequestMapping("/api/v1")
public class CandidatoServices {

    @Autowired
    private CandidatoRepository cr;

    @GetMapping()
    public String info(){
        return "<h2>Servicio Candidatos Activo</h2>";
    }

    @GetMapping("/all")
    public List<Candidato>getAll(){
        return (List<Candidato>)cr.findAll();
    }

    //swagger

}
